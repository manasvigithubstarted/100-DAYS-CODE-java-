public class ternary {
    public static void main(String[] args) {
 int n=11;
 int result =n%2==0 ? 10:20;
 System.out.println(result);
    
  }
}
