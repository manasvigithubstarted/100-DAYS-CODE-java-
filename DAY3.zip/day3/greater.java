//getting greatest number among  three numbers
public class greater {
    public static void main (String[] args) {
        int a = 10;
        int b = 20;
        int c=30;
        if (a>b && a>c)
           System.out.println("a is greatest of all"+a);
        else if(b>a && b>c)
          System.out.println("b is greatest of all +b");
        else
            System.out.println("c is greatest "+c);
    }
}
