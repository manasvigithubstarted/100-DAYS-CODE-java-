import java.util.Scanner;
public class Nestedif {
    public static void main(String[] args) {
        String ename;
        int exp;
        float salary; 
        Scanner imp = new Scanner(System.in);
        System.out.println("Enter Employee Name");
        ename= imp.nextLine();
        System.out.println("Enter Employee Experience");
        exp=imp.nextInt();
        System.out.println("Enter Employee Salary");
        salary = imp.nextFloat();
        if (exp>=15){
            if(salary>8000){
                System.out.println("your name is "+ename);
                System.out.println("congratulations");
                System.out.println("your salary is "+(salary+1500));
                }
        else{
            if(salary>6000)
            System.out.println("your name is "+ename);
            System.out.println("congrats");
            System.out.println("your salary is "+(salary+1000));
        }   
            }           
}
}