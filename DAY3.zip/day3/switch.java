public class Switch {
    public static void main(String[] args){
        int n=1;
        switch(n){
            case 1:
                 System.out.println("monday");
                 break;
            case 2:
                 System.out.println("tuesday");
                 break;
            case 3:
                 System.out.println("wedwnsda");
                 break;
            case 4:
                  System.out.println("thursday");
                 break;

                }

    }
}   

