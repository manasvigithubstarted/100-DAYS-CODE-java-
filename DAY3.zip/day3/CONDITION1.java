public class CONDITION1{
    public static void main(String[] args){
        int x=999;
        if (x>=10 && x<=100)
           System.out.println("hello");
        else
           System.out.println("bye");
        int a=10;
        int b=11;
        if (a>=10 && b>=11)
            System.out.println("hello buddy");
        else
        System.out.println("good bye ");

    }
}