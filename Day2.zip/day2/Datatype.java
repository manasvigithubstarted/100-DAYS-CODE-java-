package day2;

public class Datatype {
    int a= 55;
    boolean b=true;
    char c='A';
    float d= 45.67f;
    double e= 45.67;
    public static void main(String[] args) {
        Datatype datatype = new Datatype();
        System.out.println(datatype.a);
        System.out.println(datatype.b);
        System.out.println(datatype.c);
        System.out.println(datatype.d);
        System.out.println(datatype.e);
    }
}
