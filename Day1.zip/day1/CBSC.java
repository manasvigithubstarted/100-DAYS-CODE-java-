    import java.util.Scanner;

public class CBSC {
    public static void main(String[] args) {
      try ( Scanner sc = new Scanner(System.in)){
            System.out.println("enter marks in oops  subjects ");
            int a= sc.nextInt();
            System.out.println("enter marks in maths ");
            int b =sc.nextInt();
            System.out.println("entr your marks in aml");
            int c= sc.nextInt();
            System.out.println("enter your marks in software");
            int d= sc.nextInt();
            System.out.println("enter your marks in dcn");
            int e= sc.nextInt();
            float sum= (a+b+c+d+e)/500;
            float percentage=sum*100;
            System.out.println("your percentage is "+ percentage);
       }
   }
}
