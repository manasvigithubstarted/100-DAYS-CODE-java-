import java.util.Scanner;
class Sum{
    public static void main(String[] args) {
        System.out.println("TAKING INPUT FROM USER ");
        try(Scanner Sc = new Scanner(System.in)){;
        System.out.println("enter number 1");
        int a=Sc.nextInt();
        System.out.println("enter number 2");
        int b=Sc.nextInt();
        int add=a+b;
        System.out.println("sum of a and b are "+add);
    

}}}