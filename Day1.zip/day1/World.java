public class World {
    public static void main(String[] args) {
        System.out.println("hii buddy ");
    }
    
}
