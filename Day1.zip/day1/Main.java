import java.util.Scanner;

class ArrayUtils {
    static double findAverage(int[] array) {
        if (array.length == 0) {
            return 0;
        }

        int sum = 0;
        for (int i : array) {
            sum += i;
        }

        return (double) sum / array.length;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter the array size: ");
        int size = s.nextInt();

        if (size <= 0) {
            System.out.println("Invalid Array Size.");
            return;
        }

        int[] array = new int[size];
        System.out.println("Enter " + size + " integers: ");

        for (int i = 0; i < size; i++) {
            array[i] = s.nextInt();
        }
        s.close();

        double average = ArrayUtils.findAverage(array);
        System.out.println("Average: " + average);
    }
}